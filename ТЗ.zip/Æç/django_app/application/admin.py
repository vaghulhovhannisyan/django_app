from django.contrib import admin
from .models import menu

admin.site.register(menu)
